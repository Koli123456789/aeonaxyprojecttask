package com.crudapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crudapp.entity.User;
import com.crudapp.entity.Page2;

public interface page2repo extends JpaRepository<Page2, Integer>
{

}
