package com.crudapp.service;

import java.util.List;

import org.slf4j.helpers.Reporter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crudapp.entity.User;
import com.crudapp.repository.userrepo;

@Service
public class userserviceimpl implements userservice
{
	@Autowired
	private userrepo repo;

	@Override
	public void saveUser(User ur) 
	{
		repo.save(ur);
	}

	@Override
	public List<User> getAllUser() {
		return repo.findAll();
	}

	@Override
	public void deleteUserById(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUserById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateUser(User ur) {
		// TODO Auto-generated method stub
		
	}

}
