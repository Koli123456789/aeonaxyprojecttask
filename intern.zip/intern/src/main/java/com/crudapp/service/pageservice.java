package com.crudapp.service;

public interface pageservice 
{

}
