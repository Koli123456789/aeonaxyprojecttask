package com.crudapp.service;

import java.util.List;

import com.crudapp.entity.User;

public interface userservice 
{
	void saveUser(User ur); //insert record
	
	List<User> getAllUser(); //show all records
	
	void deleteUserById(Integer id); //delete record by employee id
	
	User getUserById(Integer id); // update a single record by id
	
	void updateUser(User ur); //update the record
}
