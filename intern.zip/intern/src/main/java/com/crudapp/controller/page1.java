package com.crudapp.controller;

import java.io.File;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.crudapp.entity.User;
import com.crudapp.repository.userrepo;
import com.crudapp.service.userservice;



@Controller
public class page1
{
	@Autowired
	private userrepo repo;
	
	@Autowired
	private userservice service; 
	
	@GetMapping("show")
	public String page1()
	{
		return "page1";
	}
	
	@GetMapping("show2")
	public String page2()
	{
		return "page2";
	}
	
	@GetMapping("show3")
	public String page3()
	{
		return "page3";
	}
	
	/*@GetMapping("show4")
	public String page4()
	{
		return "page4";
	}*/
	@PostMapping("/register")
	public String saveUser(@ModelAttribute User ur)
	{
		service.saveUser(ur);
		return "redirect:/show2";
	}
	@GetMapping("/page")
	public String show(@RequestParam(name = "email", required = false) String email,Model model)
	{
		List<User> list=service.getAllUser();
		model.addAttribute("email", email);
		return "page4";
	}
	@PostMapping("/Upload")
	public String imageUpload( @ModelAttribute User user,@RequestParam("img") MultipartFile img,Model model)
	{
		
	    try {
            // Set the image name in the product
            user.setImagename(img.getOriginalFilename());

            // Save the product with name, price, and image name to the database
            User uploadedProduct = repo.save(user);

            if (uploadedProduct != null) {
                // Save the image file to the "static/img" directory
                File saveDir = new ClassPathResource("static/image").getFile();

                // Ensure the directory exists, create it if not
                if (!saveDir.exists()) {
                    saveDir.mkdirs();
                }

                // Path to save the image file
                Path path = Paths.get(saveDir.getAbsolutePath() + File.separator + img.getOriginalFilename());

                // Copy the image file
                Files.copy(img.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

                model.addAttribute("successMessage", "Product added successfully!");
                
                return "redirect:show3";
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions, redirect to an error page, or show an error message
        }

	    
        // Return an error page if something goes wrong
        return "show3";
    }
}
